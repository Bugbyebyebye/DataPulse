package service

import (
	"fmt"
	"gorm.io/gorm"
	"log"
	"mysql-first/common"
	"mysql-first/dao"
)

// GetColumnNameList  获取数据表的列名
func GetColumnNameList(db *gorm.DB, databaseName string) []common.Table {
	var tableList []common.Table
	var table common.Table
	var tables []string
	//获取数据库下的全部数据表名
	rows, err := db.Raw("SHOW TABLES").Rows()
	if err != nil {
		panic(err.Error())
	}
	for rows.Next() {
		var name string
		if err := rows.Scan(&name); err != nil {
			fmt.Printf("err => %s\n", err)
		}
		tables = append(tables, name)
	}
	//fmt.Printf("Tables: %s\n", tables)

	//获取数据表中全部字段名
	for _, tableName := range tables {
		var columns []string
		var info []common.TableInfo
		query := "desc " + tableName
		db.Raw(query).Scan(&info)
		for _, v := range info {
			if v.Field[len(v.Field)-2:] == "id" {
				table.RelateFlag = v.Field
			}
			columns = append(columns, v.Field)
		}

		table.SourceName = "mysql1"
		table.DatabaseName = databaseName
		table.TableName = tableName
		table.ColumnList = columns
		tableList = append(tableList, table)
	}
	return tableList
}

// filterDataByColumnFormat 过滤不符合格式的字段，并记录异常或空数据的概率
func filterDataByColumnFormatAndRecord(data []map[string]interface{}, columns []string) ([]map[string]interface{}, map[string]float64) {
	var filteredResults []map[string]interface{}
	var errorProbability = make(map[string]float64)

	totalRows := float64(len(data))
	for _, item := range data {
		validData := true
		for _, column := range columns {
			if value, ok := item[column]; ok {
				// 如果字段值为空，则标记为无效数据
				if value == "" {
					validData = false
					errorProbability[column] += 1.0
					break
				}
				// 添加其他异常值处理逻辑
			} else {
				validData = false
				errorProbability[column] += 1.0
				break
			}
		}
		if validData {
			filteredResults = append(filteredResults, item)
		}
	}
	// 计算异常或空数据的概率
	for col, count := range errorProbability {
		errorProbability[col] = count / totalRows
	}

	return filteredResults, errorProbability
}

// GetDataByColumnList 获取数据表中指定字段的数据
func GetDataByColumnList(table common.Table) ([]map[string]interface{}, map[string]float64) {
	databaseName := table.DatabaseName

	// 根据传入的数据库选择操作数据库的对象
	var db *gorm.DB
	if databaseName == "df_education" {
		db = dao.Education
	} else if databaseName == "df_library" {
		db = dao.Library
	}
	// 数据表列表中的table
	log.Printf("table => %+v", table)
	log.Printf("column => %+v", table.ColumnList)

	result := dao.QueryColumnData(db, table.TableName, table.ColumnList)
	log.Printf("result => %+v", result)
	filteredResults, errorProbability := filterDataByColumnFormatAndRecord(result, table.ColumnList)
	return filteredResults, errorProbability
}
