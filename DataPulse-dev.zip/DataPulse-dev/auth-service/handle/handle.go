package handle

type AuthHandler struct {
}

func New() *AuthHandler {
	return &AuthHandler{}
}
