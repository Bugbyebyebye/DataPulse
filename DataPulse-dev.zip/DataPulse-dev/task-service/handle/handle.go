package handle

type TaskHandle struct {
}

func New() *TaskHandle {
	return &TaskHandle{}
}
